#include <uC++.h>
#include <uFuture.h>
#include <iostream>
#include <fstream>

using namespace std;

class WATCard {
	public:
	unsigned int balance;
    typedef Future_ISM<WATCard *> FWATCard;   // future watcard pointer
    WATCard() : balance( 0 ) { }
};



class one{
	
public:
	WATCard *watcard;                           // call arguments (YOU DEFINE "Args")
    WATCard::FWATCard result; 
	one(): watcard(watcard) {}
	WATCard::FWATCard create( unsigned int sid, unsigned int amount ) {
		watcard = new WATCard();
		watcard->balance += 5;
		return result;
	}
};


int main() {
	one * Two = new one();
	WATCard::FWATCard acard2 = Two->create(1, 20);

	one * One = new one();
	WATCard::FWATCard acard = One->create(1, 20);
	One->result.delivery(One->watcard);

	
	Two->result.delivery(Two->watcard);
	for (int i = 0; i < 2; i++) {
		_Select(acard2) {
			cout << acard2()->balance << endl;
			acard2.reset();
		} or _Select(acard) {
			cout << "hi" << endl;
		}
	}
	delete acard();
	//delete acard2();
	delete One;
	delete Two;
	return 0;
}
