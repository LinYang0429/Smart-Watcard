#include "vendingmachine.h"
#include "student.h"
#include "printer.h"
#include "nameserver.h"
#include "watcardoffice.h"
#include "groupoff.h"
#include "watcard.h"
#include "mprng.h"

extern MPRNG mprng;

void VendingMachine::main() {
	for (;;) {
		_Accept( ~VendingMachine ) {
			break;
		} or _Accept( buy ) {
		} or _Accept( inventory ) {
			prt.print( Printer::Kind.Vending, id, 'r' );
			_Accept( restocked ) {
			}
		}
	}
	delete [] stock;
}

VendingMachine::VendingMachine( Printer &prt, NameServer &nameServer, unsigned int id, unsigned int sodaCost,
	unsigned int maxStockPerFlavour ) : prt( prt ), nameServer( nameServer ), id( id ), sodaCost( sodaCost ),
	maxStockPerFlavour( maxStockPerFlavour ), buying( false ) {
	stock = new unsigned int[4];
	for( int i = 0; i < 4; i++ ) {
		stock[i] = 0;
	}
}

void VendingMachine::buy( Flavours flavour, WATCard &card ) {
	unsigned int watCardBalance = card.getBalance();
	if ( watCardBalance < sodaCost ) {
		_Throw( Funds );
	}
	if ( stock[( int ) flavour] == 0 ) {
		_Throw( Stock );
	}
	if ( mprng( 1, 5 ) == 1 ) {
		_Throw( Free );
	}
	card.withdraw( sodaCost );
	stock[ ( int ) flavour ]--;
	prt.print( Printer::Kind.Vending, id, 'B', ( int ) flavour, watCardBalance - sodaCost );
}

unsigned int *VendingMachine::inventory() {
	// start reloading print in main function
	return stock;
}

void VendingMachine::restocked() {
	prt.print( Printer::Kind.Vending, id, 'R' );
}

_Nomutex unsigned int VendingMachine::cost() {
	return sodaCost;
}

_Nomutex unsigned int VendingMachine::getId() {
	return id;
}