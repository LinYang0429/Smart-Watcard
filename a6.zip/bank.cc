#include "bank.h"
using namespace std;

Bank::Bank( unsigned int numStudents ) {
	belances = new unsigned int[numStudents];
	for(unsigned int i = 0; i < numStudents; i++) {
		belances[i] = 0;
	}
}

Bank::~Bank() {
	delete [] belances;
}

void Bank::deposit( unsigned int id, unsigned int amount ) {
	belances[id] += amount;
}

void Bank::withdraw( unsigned int id, unsigned int amount ) {
	while (amount > belances[id]) {
		_Accept(deposit);
	}
	belances -= amount;
}