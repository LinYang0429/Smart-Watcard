#include "bottlingplant.h"
#include "printer.h"
#include "nameserver.h"
#include "vendingmachine.h"
#include "truck.h"
#include "mprng.h"

extern MPRNG mprng;

void BottlingPlant::main() {
	prt.print( Printer::Kind.BottlingPlant, 'S');
	Truck truck = new Truck( prt, nameServer, this, numVendingMachines, maxStockPerFlavour );
	for(;;) {
		int total = 0;
		for( int i = 0; i < 4; i++ ) {	// production run of soda
			stock[i] = mprng( 1, maxShippedPerFlavour );
			total += stock[i];
		}
		yield( timeBetweenShipments );
		prt.print( Printer::Kind.BottlingPlant, 'G', total );
		_Accept( ~VendingMachine ) {
			shutdown = true;
			break;
		} or _Accept( getShipment ) {
			prt.print( Printer::Kind.BottlingPlant, 'P');
		}
	}
	delete truck;
	delete [] stock;
	prt.print( Printer::Kind.BottlingPlant, 'F');
}

BottlingPlant::BottlingPlant( Printer &prt, NameServer &nameServer, unsigned int numVendingMachines,
                 unsigned int maxShippedPerFlavour, unsigned int maxStockPerFlavour,
                 unsigned int timeBetweenShipments ) : prt( prt ), nameServer( nameServer ), 
				 numVendingMachines( numVendingMachines ), maxShippedPerFlavour( maxShippedPerFlavour ),
				 maxStockPerFlavour( maxStockPerFlavour ), timeBetweenShipments( timeBetweenShipments ),
				 shutdown( false ) {
	stock = new unsigned int[4];
	for( int i = 0; i < 4; i++ ) {
		stock[i] = 0;
	}
}

void BottlingPlant::getShipment( unsigned int cargo[] ) {
	if ( shutdown ) {
		_Throw( Shutdown );
	}
	for( int i = 0; i < 4; i++ ) {
		cargo[i] = stock[i];
	}
}